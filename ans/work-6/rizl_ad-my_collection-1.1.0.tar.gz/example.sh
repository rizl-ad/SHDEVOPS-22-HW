ansible-playbook instances.yml
ansible-playbook stack.yml